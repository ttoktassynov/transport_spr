#pragma once
#include <optional>
#include <string>
#include <vector>
#include <unordered_map>
#include <iomanip>
#include <set>

const double PI = 3.1415926535;
const double RADIUS = 6371000;

struct RouteStats{
    size_t stops;
    size_t unique_stops;
    double length;
};

struct StopStats{
    std::set<std::string> routes;
};

struct Response;
using ResponseHolder = std::unique_ptr<Response>;

struct Response{
    enum class Type {
        SEND_ROUTE,
        SEND_STOP
    };

    Response(Type type) : type(type) {}
    static ResponseHolder Create(Type type);
    virtual ~Response() = default;

    const Type type;
};

struct ReadRouteResponse : Response {
    ReadRouteResponse () : Response(Response::Type::SEND_ROUTE) {}
    std::string route;
    std::optional<RouteStats> stats;
};

struct ReadStopResponse : Response {
    ReadStopResponse () : Response(Response::Type::SEND_STOP) {}
    std::string stop;
    bool hasStop;
    std::optional<StopStats> stats;
};

struct Coordinate{
    double lat;
    double lon;
};

double DistanceBetweenCoordinates(const Coordinate& lhs, const Coordinate& rhs);

std::ostream& operator << (std::ostream& output, 
    const ReadRouteResponse data);

std::ostream& operator << (std::ostream& output,
    const ReadStopResponse data);

double ConvertToRad(double val);


class RouteManager{
public:
    ResponseHolder ReadRoute(std::string route) const;
    ResponseHolder ReadStop(std::string stop) const;
    void AddStop(std::string stop, double lat, double lon);
    void AddRoute(std::string route, std::vector<std::string> stops);

private:
    using RouteInfo = std::vector<std::string>;
    using StopInfo = std::set<std::string>;
    std::unordered_map<std::string, Coordinate> stops_;
    std::unordered_map<std::string, RouteInfo> route_to_stops_;
    std::unordered_map<std::string, StopInfo> stop_to_routes_;
    double ComputeStopsDistance(const std::vector<std::string>& stops) const;
};