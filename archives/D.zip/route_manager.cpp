#include "route_manager.h"
#include <cmath>
#include <algorithm>
using namespace std;

ResponseHolder RouteManager::ReadRoute(string route, int request_id) const{
    ReadRouteResponse response;

    response.request_id = request_id;
    response.route = route;

    if (route_to_stops_.count(route)){  
        const vector<string>& stops = route_to_stops_.at(route);

        size_t num_of_stops = stops.size();

        vector<string> tmp(stops);
        sort(begin(tmp), end(tmp));
        auto last = unique(begin(tmp), end(tmp));
        tmp.erase(last, end(tmp));

        size_t num_of_unique_stops = tmp.size();

        int route_real_dist = ComputeRouteRealDistance(stops);
        double route_geo_dist = ComputeRouteGeoDistance(stops);
        double curvature = route_real_dist / route_geo_dist;
        
        response.stats = RouteStats{num_of_stops, 
                                    num_of_unique_stops, 
                                    route_real_dist, 
                                    curvature};
    }
    else{
        response.stats = nullopt;
    }
    return make_unique<ReadRouteResponse>(response);
}

ResponseHolder RouteManager::ReadStop(string stop, int request_id) const {
    ReadStopResponse response;

    response.request_id = request_id;
    response.stop = stop;
    response.hasStop = stops_.count(stop);

    if (stop_to_routes_.count(stop)){
        response.stats = StopStats{stop_to_routes_.at(stop)};
    }
    else{
        response.stats = nullopt;
    }
    return make_unique<ReadStopResponse>(response);
}


void RouteManager::AddStop(string stop, double lat, double lon, optional<DistInfo> other_stops){
    stops_[stop] = {lat, lon};
    if (other_stops){
        for (auto& [distance, other_stop] : *other_stops){
            distances_[make_pair(stop, other_stop)] = distance;
            if (!distances_.count(make_pair(other_stop, stop)))
                distances_[make_pair(other_stop, stop)] = distance;
        }
    }
}
void RouteManager::AddRoute(string route, vector<string> stops){
    for (const auto& stop : stops){
        stop_to_routes_[stop].insert(route);
    }
    route_to_stops_[route] = move(stops);
}

double RouteManager::ComputeRouteGeoDistance(const vector<string>& stops) const{
    double total = 0;
    for (int i = 1; i < stops.size(); ++i){
        const Coordinate start = stops_.at(stops[i - 1]);
        const Coordinate end = stops_.at(stops[i]);
        total += DistanceBetweenCoordinates(start, end);
    }
    return total;
}

int RouteManager::ComputeRouteRealDistance(const std::vector<std::string>& stops) const {
    int total = 0;
    for (int i = 1; i < stops.size(); ++i){
        if (distances_.count(make_pair(stops[i - 1], stops[i]))){
            total += distances_.at(make_pair(stops[i - 1], stops[i]));
        }
    }
    return total;
}

