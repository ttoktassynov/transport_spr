#include "request.h"
#include <iostream>
#include <memory>

using namespace std;

pair<string_view, optional<string_view>> SplitTwoStrict(string_view s, string_view delimiter) {
  const size_t pos = s.find(delimiter);
  if (pos == s.npos) {
    return {s, nullopt};
  } else {
    return {s.substr(0, pos), s.substr(pos + delimiter.length())};
  }
}

pair<string_view, string_view> SplitTwo(string_view s, string_view delimiter) {
  const auto [lhs, rhs_opt] = SplitTwoStrict(s, delimiter);
  return {lhs, rhs_opt.value_or("")};
}

string_view ReadToken(string_view& s, string_view delimiter) {
  const auto [lhs, rhs] = SplitTwo(s, delimiter);
  s = rhs;
  return lhs;
}

int ConvertToInt(string_view str) {
  // use std::from_chars when available to git rid of string copy
  size_t pos;
  const int result = stoi(string(str), &pos);
  if (pos != str.length()) {
    stringstream error;
    error << "string " << str << " contains " << (str.length() - pos) << " trailing chars";
    throw invalid_argument(error.str());
  }
  return result;
}

double ConvertToDouble(string_view str){
    size_t pos;
    const double result = stod(string(str), &pos);
    if (pos != str.length()) {
        stringstream error;
        error << "string " << str << " contains " << (str.length() - pos) << " trailing chars";
        throw invalid_argument(error.str()); 
    }
    return result;
}

void AddStopRequest::ParseFrom(const RequestMap& map) {
  stop = map.at("name").AsString();
  lat = map.at("latitude").AsDouble();
  lon = map.at("longitude").AsDouble();
  
  const RequestMap& dist_map = map.at("road_distances").AsMap();
  for (const auto [other_stop, dist_node] : dist_map){
      int distance = static_cast<int>(dist_node.AsDouble());
      other_stops.push_back(make_pair(distance, other_stop));
  }
}

void AddStopRequest::Process(RouteManager& manager) const {
  manager.AddStop(stop, lat, lon, 
    (!other_stops.empty()) ? optional<RouteManager::DistInfo>(other_stops) : nullopt);
}

void AddRouteRequest::ParseFrom(const RequestMap& map) {
  route = map.at("name").AsString();

  deque<string> back_stops;
  bool is_roundtrip = map.at("is_roundtrip").AsBool();
  const RequestArray& route_stops = map.at("stops").AsArray();

  size_t i = 0;
  for (const auto& stop_node : route_stops ){
      string stop = stop_node.AsString();

      if (!is_roundtrip && i < route_stops.size() - 1) 
        back_stops.push_front(stop);
      ++i;
      stops.push_back(stop);
  }
  
  if (!is_roundtrip){
      stops.reserve(stops.size() + back_stops.size());
      move(begin(back_stops), end(back_stops), back_inserter(stops));
  }
}

void AddRouteRequest::Process(RouteManager& manager) const {
  manager.AddRoute(route, stops);
}

RequestHolder Request::Create(Request::Type type) {
  switch (type) {
    case Request::Type::ADD_STOP:
      return make_unique<AddStopRequest>();
    case Request::Type::ADD_ROUTE:
      return make_unique<AddRouteRequest>();
    case Request::Type::READ_ROUTE:
      return make_unique<ReadRouteRequest>();
    case Request::Type::READ_STOP:
      return make_unique<ReadStopRequest>();
    default:
      return nullptr;
  }
}

optional<Request::Type> ConvertBaseRequestType(string_view type_str) {
  if (const auto it = STR_TO_UPDATE_REQUEST_TYPE.find(type_str);
      it != STR_TO_UPDATE_REQUEST_TYPE.end()) {
    return it->second;
  } else {
    return nullopt;
  }
}

optional<Request::Type> ConvertStatRequestType(string_view type_str) {
  if (const auto it = STR_TO_READ_REQUEST_TYPE.find(type_str);
      it != STR_TO_READ_REQUEST_TYPE.end()) {
    return it->second;
  } else {
    return nullopt;
  }
}

vector<ResponseHolder> ProcessRequests(const vector<RequestHolder>& requests, 
  RouteManager& manager) {
  vector<ResponseHolder> responses;
  responses.reserve(requests.size());

  for (const auto& request_holder : requests) {
    if (request_holder->type == Request::Type::READ_ROUTE) {
      const auto& request = static_cast<const ReadRouteRequest&>(*request_holder);
      ResponseHolder rh = request.Process(manager);
      responses.push_back(move(rh));
    }
    else if (request_holder->type == Request::Type::READ_STOP) {
      const auto& request = static_cast<const ReadStopRequest&>(*request_holder);
      responses.push_back(request.Process(manager));
    } 
    else {
      const auto& request = static_cast<const BaseRequest&>(*request_holder);
      request.Process(manager);
    }
  }
  return responses;
}

void PrintResponses(const vector<ResponseHolder>& responses, ostream& stream) {
  stream << "[";
  size_t i = 0;
  for (const ResponseHolder& response_holder : responses) {
    stream << "{";
    if (response_holder->type == Response::Type::SEND_ROUTE) {
      const auto& response = static_cast<const ReadRouteResponse&>(*response_holder);
      stream << response << endl;
    }
    else if (response_holder->type == Response::Type::SEND_STOP) {
      const auto& response = static_cast<const ReadStopResponse&>(*response_holder);
      stream << response << endl;
    }
    if (i < responses.size() - 1) stream << "},";
    else stream << "}";
    ++i;
  }
  stream << "]"; 
}