#include "response.h"



std::ostream& operator << (std::ostream& output, 
    const ReadRouteResponse data){
    using std::operator""s;
    output << std::fixed << std::setprecision(6);
    output << "\"" << "request_id"s << "\"" << ": "
                  << data.request_id << ",";

    if (!data.stats){
        output << "\"" << "error_message"s << "\"" << ": ";
        return output << "\"" << "not found"s << "\"";
    }
    return output << "\"" << "route_length"s << "\"" << ": "
                  << data.stats->length << ","
                  << "\"" << "curvature"s << "\"" << ": "
                  << data.stats->curvature << ","
                  << "\"" << "stop_count"s << "\"" << ": "
                  << data.stats->stops << ","
                  << "\"" << "unique_stop_count"s << "\"" << ": "
                  << data.stats->unique_stops;
}

std::ostream& operator << (std::ostream& output,
    const ReadStopResponse data){
    using std::operator""s;
    output << "\"" << "request_id"s << "\"" << ": ";
    output << data.request_id << ",";

    if (!data.stats){
        if (!data.hasStop){
            output << "\"" << "error_message"s << "\"" << ": ";
            output << "\"" << "not found"s << "\"";
        }
        else {
            output << "\"" << "buses"s << "\"" << ": []";
        }
    }
    else{
        output << "\"" << "buses"s << "\"" << ": [";
        size_t i = 0;
        for (const std::string& route : data.stats->routes){
            output << "\"" << route << "\"";
            if (i < data.stats->routes.size() - 1) 
              output << ",";
            ++i;
        }
        output << "]";
    }
    return output;
}
double ConvertToRad(double val){
    return val * PI / 180;
}

double DistanceBetweenCoordinates(const Coordinate& x, const Coordinate& y){
    double lat_x_r = ConvertToRad(x.lat);
    double lon_x_r = ConvertToRad(x.lon);

    double lat_y_r = ConvertToRad(y.lat);
    double lon_y_r = ConvertToRad(y.lon);

    return acos(sin(lat_x_r) * sin(lat_y_r) + 
            cos(lat_x_r) * cos(lat_y_r) * 
            cos(std::abs(lon_x_r - lon_y_r))) * RADIUS;
}

ResponseHolder Response::Create(Response::Type type) {
  switch (type) {
    case Response::Type::SEND_ROUTE:
      return std::make_unique<ReadRouteResponse>();
    case Response::Type::SEND_STOP:
      return std::make_unique<ReadStopResponse>();
    default:
      return nullptr;
  }
}