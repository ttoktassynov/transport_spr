#pragma once
#include <set>
#include <string>
#include <memory>
#include <sstream>
#include <optional>
#include <iomanip>
#include <cmath>

const double PI = 3.1415926535;
const double RADIUS = 6371000;

struct RouteStats{
    size_t stops;
    size_t unique_stops;
    int length;
    double curvature;
};

struct StopStats{
    std::set<std::string> routes;
};

struct Response;
using ResponseHolder = std::unique_ptr<Response>;

struct Response{
    enum class Type {
        SEND_ROUTE,
        SEND_STOP
    };

    Response(Type type) : type(type) {}
    static ResponseHolder Create(Type type);
    virtual ~Response() = default;

    const Type type;
    int request_id;
};

struct ReadRouteResponse : Response {
    ReadRouteResponse () : Response(Response::Type::SEND_ROUTE) {}
    std::string route;
    std::optional<RouteStats> stats;
};

struct ReadStopResponse : Response {
    ReadStopResponse () : Response(Response::Type::SEND_STOP) {}
    std::string stop;
    bool hasStop;
    std::optional<StopStats> stats;
};

struct Coordinate{
    double lat;
    double lon;
};

double DistanceBetweenCoordinates(const Coordinate& lhs, const Coordinate& rhs);

std::ostream& operator << (std::ostream& output, 
    const ReadRouteResponse data);

std::ostream& operator << (std::ostream& output,
    const ReadStopResponse data);

double ConvertToRad(double val);
