#include "test_runner.h"
#include "request.h"
#include "route_manager.h"
#include "test_runner.h"

void TestUpdateRequests();
void TestReadRequests();
void TestResponses();

int main(){
    //freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);
    TestRunner tr;
    //RUN_TEST(tr, TestUpdateRequests);
    //RUN_TEST(tr, TestReadRequests);
    //RUN_TEST(tr, TestResponses);
    
    RouteManager manager;
    
    const auto update_requests = ReadRequests<0>();
    ProcessRequests(update_requests, manager);
    const auto read_requests = ReadRequests<1>();
    const auto responses = ProcessRequests(read_requests, manager);
    PrintResponses(responses);
}
