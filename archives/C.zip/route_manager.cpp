#include "route_manager.h"
#include <cmath>
#include <algorithm>
using namespace std;

std::ostream& operator << (std::ostream& output, 
    const ReadRouteResponse data){
    output << fixed << setprecision(6);
    if (!data.stats){
        return output << "Bus " 
                        << data.route 
                        << ": not found";
    }
    return output << "Bus "
                << data.route << ": " 
                << data.stats->stops << " stops on route, "
                << data.stats->unique_stops << " unique stops, "
                << data.stats->length << " route length, "
                << data.stats->curvature << " curvature";
}

std::ostream& operator << (std::ostream& output,
    const ReadStopResponse data){
    output << "Stop " <<  data.stop << ": ";
    if (!data.stats){
        if (!data.hasStop){
            output << "not found";
        }
        else {
            output << "no buses";
        }
    }
    else{
        output << "buses ";
        for (const string& route : data.stats->routes){
            output << route << " ";
        }
    }
    return output;
}

double DistanceBetweenCoordinates(const Coordinate& lhs, const Coordinate& rhs){
    return acos(sin(lhs.lat) * sin(rhs.lat) + 
            cos(lhs.lat) * cos(rhs.lat) * 
            cos(abs(lhs.lon - rhs.lon))) * RADIUS;
}

ResponseHolder RouteManager::ReadRoute(string route) const{
    ReadRouteResponse response;
    response.route = route;
    if (route_to_stops_.count(route)){  
        const vector<string>& stops = route_to_stops_.at(route);

        size_t num_of_stops = stops.size();

        vector<string> tmp(stops);
        sort(begin(tmp), end(tmp));
        auto last = unique(begin(tmp), end(tmp));
        tmp.erase(last, end(tmp));

        size_t num_of_unique_stops = tmp.size();

        int route_real_dist = ComputeRouteRealDistance(stops);
        double route_geo_dist = ComputeRouteGeoDistance(stops);
        double curvature = route_real_dist / route_geo_dist;
        
        response.stats = RouteStats{num_of_stops, 
                                    num_of_unique_stops, 
                                    route_real_dist, 
                                    curvature};
    }
    else{
        response.stats = nullopt;
    }
    return make_unique<ReadRouteResponse>(response);
}

ResponseHolder RouteManager::ReadStop(string stop) const {
    ReadStopResponse response;
    response.stop = stop;
    response.hasStop = stops_.count(stop);
    if (stop_to_routes_.count(stop)){
        response.stats = StopStats{stop_to_routes_.at(stop)};
    }
    else{
        response.stats = nullopt;
    }
    return make_unique<ReadStopResponse>(response);
}
double ConvertToRad(double val){
    return val * PI / 180;
}

void RouteManager::AddStop(string stop, double lat, double lon, optional<DistInfo> other_stops){
    stops_[stop] = {ConvertToRad(lat), ConvertToRad(lon)};
    if (other_stops){
        for (auto& [distance, other_stop] : *other_stops){
            distances_[make_pair(stop, other_stop)] = distance;
            if (!distances_.count(make_pair(other_stop, stop)))
                distances_[make_pair(other_stop, stop)] = distance;
        }
    }
}
void RouteManager::AddRoute(string route, vector<string> stops){
    for (const auto& stop : stops){
        stop_to_routes_[stop].insert(route);
    }
    route_to_stops_[route] = move(stops);
}

double RouteManager::ComputeRouteGeoDistance(const vector<string>& stops) const{
    double total = 0;
    for (int i = 1; i < stops.size(); ++i){
        const Coordinate start = stops_.at(stops[i - 1]);
        const Coordinate end = stops_.at(stops[i]);
        total += DistanceBetweenCoordinates(start, end);
    }
    return total;
}

int RouteManager::ComputeRouteRealDistance(const std::vector<std::string>& stops) const {
    int total = 0;
    for (int i = 1; i < stops.size(); ++i){
        if (distances_.count(make_pair(stops[i - 1], stops[i]))){
            total += distances_.at(make_pair(stops[i - 1], stops[i]));
        }
    }
    return total;
}

ResponseHolder Response::Create(Response::Type type) {
  switch (type) {
    case Response::Type::SEND_ROUTE:
      return make_unique<ReadRouteResponse>();
    case Response::Type::SEND_STOP:
      return make_unique<ReadStopResponse>();
    default:
      return nullptr;
  }
}