#include "request.h"
#include <iostream>
#include <memory>

using namespace std;

pair<string_view, optional<string_view>> SplitTwoStrict(string_view s, string_view delimiter) {
  const size_t pos = s.find(delimiter);
  if (pos == s.npos) {
    return {s, nullopt};
  } else {
    return {s.substr(0, pos), s.substr(pos + delimiter.length())};
  }
}

pair<string_view, string_view> SplitTwo(string_view s, string_view delimiter) {
  const auto [lhs, rhs_opt] = SplitTwoStrict(s, delimiter);
  return {lhs, rhs_opt.value_or("")};
}

string_view ReadToken(string_view& s, string_view delimiter) {
  const auto [lhs, rhs] = SplitTwo(s, delimiter);
  s = rhs;
  return lhs;
}

int ConvertToInt(string_view str) {
  // use std::from_chars when available to git rid of string copy
  size_t pos;
  const int result = stoi(string(str), &pos);
  if (pos != str.length()) {
    stringstream error;
    error << "string " << str << " contains " << (str.length() - pos) << " trailing chars";
    throw invalid_argument(error.str());
  }
  return result;
}

double ConvertToDouble(string_view str){
    size_t pos;
    const double result = stod(string(str), &pos);
    if (pos != str.length()) {
        stringstream error;
        error << "string " << str << " contains " << (str.length() - pos) << " trailing chars";
        throw invalid_argument(error.str()); 
    }
    return result;
}
void ReadRouteRequest::ParseFrom(string_view input) {
  route = ReadToken(input, "\n");
}

ResponseHolder ReadRouteRequest::Process(const RouteManager& manager) const {
  return manager.ReadRoute(route);
}

void ReadStopRequest::ParseFrom(string_view input) {
  stop = ReadToken(input, "\n");
}

ResponseHolder ReadStopRequest::Process(const RouteManager& manager) const {
  return manager.ReadStop(stop);
}

void AddStopRequest::ParseFrom(string_view input) {
  stop = ReadToken(input, ": ");
  lat = ConvertToDouble(ReadToken(input, ", "));
  lon = ConvertToDouble(ReadToken(input, ", "));
  
  string other_stop;
  int distance;

  while (!input.empty()){
      distance = ConvertToInt(ReadToken(input, "m to "));
      other_stop = ReadToken(input, ", ");
      other_stops.push_back(make_pair(distance, move(other_stop)));
  }
}

void AddStopRequest::Process(RouteManager& manager) const {
  manager.AddStop(move(stop), lat, lon, 
    (!other_stops.empty()) ? optional<RouteManager::DistInfo>(other_stops) : nullopt);
}

void AddRouteRequest::ParseFrom(string_view input) {
  route = ReadToken(input, ": ");

  deque<string> back_stops;
  bool circle = IsCircle(input);
  string delimeter = circle ? " > " : " - ";
  string stop;
  
  while (!input.empty()){
      stop = ReadToken(input, delimeter);
      if (!circle && !input.empty()) 
        back_stops.push_front(stop);
      stops.push_back(move(stop));
  }
  
  if (!circle){
      stops.reserve(stops.size() + back_stops.size());
      move(begin(back_stops), end(back_stops), back_inserter(stops));
  }
}

void AddRouteRequest::Process(RouteManager& manager) const {
  manager.AddRoute(move(route), move(stops));
}

bool AddRouteRequest::IsCircle(string_view input, string_view delimeter){
  const size_t pos = input.find(delimeter);
  if (pos  == input.npos){
      return false;
  }
  return true;
}

RequestHolder Request::Create(Request::Type type) {
  switch (type) {
    case Request::Type::ADD_STOP:
      return make_unique<AddStopRequest>();
    case Request::Type::ADD_ROUTE:
      return make_unique<AddRouteRequest>();
    case Request::Type::READ_ROUTE:
      return make_unique<ReadRouteRequest>();
    case Request::Type::READ_STOP:
      return make_unique<ReadStopRequest>();
    default:
      return nullptr;
  }
}

optional<Request::Type> ConvertUpdateRequestType(string_view type_str) {
  if (const auto it = STR_TO_UPDATE_REQUEST_TYPE.find(type_str);
      it != STR_TO_UPDATE_REQUEST_TYPE.end()) {
    return it->second;
  } else {
    return nullopt;
  }
}

optional<Request::Type> ConvertReadRequestType(string_view type_str) {
  if (const auto it = STR_TO_READ_REQUEST_TYPE.find(type_str);
      it != STR_TO_READ_REQUEST_TYPE.end()) {
    return it->second;
  } else {
    return nullopt;
  }
}

vector<ResponseHolder> ProcessRequests(const vector<RequestHolder>& requests, 
  RouteManager& manager) {
  vector<ResponseHolder> responses;
  responses.reserve(requests.size());

  for (const auto& request_holder : requests) {
    if (request_holder->type == Request::Type::READ_ROUTE) {
      const auto& request = static_cast<const ReadRouteRequest&>(*request_holder);
      ResponseHolder rh = request.Process(manager);
      responses.push_back(move(rh));
    }
    else if (request_holder->type == Request::Type::READ_STOP) {
      const auto& request = static_cast<const ReadStopRequest&>(*request_holder);
      responses.push_back(request.Process(manager));
    } 
    else {
      const auto& request = static_cast<const ModifyRequest&>(*request_holder);
      request.Process(manager);
    }
  }
  return responses;
}

void PrintResponses(const vector<ResponseHolder>& responses, ostream& stream) {
  for (const ResponseHolder& response_holder : responses) {
    if (response_holder->type == Response::Type::SEND_ROUTE) {
      const auto& response = static_cast<const ReadRouteResponse&>(*response_holder);
      stream << response << endl;
    }
    else if (response_holder->type == Response::Type::SEND_STOP) {
      const auto& response = static_cast<const ReadStopResponse&>(*response_holder);
      stream << response << endl;
    }
  }
}