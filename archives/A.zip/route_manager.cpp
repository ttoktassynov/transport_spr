#include "route_manager.h"
#include <cmath>
#include <algorithm>
using namespace std;

ostream& operator << (ostream& output, const pair<string, optional<RouteStats> >stats){
    output << fixed << setprecision(6);
    if (!stats.second){
        return output << "Bus " 
                        << stats.first 
                        << ": not found";
    }
    return output << "Bus "
                << stats.first << ": " 
                << stats.second->stops << " stops on route, "
                << stats.second->unique_stops << " unique stops, "
                << stats.second->length << " route length";
}

double DistanceBetweenCoordinates(const Coordinate& lhs, const Coordinate& rhs){
    return acos(sin(lhs.lat) * sin(rhs.lat) + 
            cos(lhs.lat) * cos(rhs.lat) * 
            cos(abs(lhs.lon - rhs.lon))) * RADIUS;
}

optional<RouteStats> RouteManager::ReadRoute(string route) const{
    if (routes_.count(route)){  
        const vector<string>& stops = routes_.at(route);

        size_t num_of_stops = stops.size();

        vector<string> tmp(stops);
        sort(begin(tmp), end(tmp));
        auto last = unique(begin(tmp), end(tmp));
        tmp.erase(last, end(tmp));

        size_t num_of_unique_stops = tmp.size();

        double route_dist = ComputeStopsDistance(stops);
        return RouteStats{num_of_stops, num_of_unique_stops, route_dist};
    }
    return nullopt;
}
double ConvertToRad(double val){
    return val * PI / 180;
}

void RouteManager::AddStop(string stop, double lat, double lon){
    stops_[stop] = {ConvertToRad(lat), ConvertToRad(lon)};
}
void RouteManager::AddRoute(string route, vector<string> stops){
    routes_[route] = move(stops);
}

double RouteManager::ComputeStopsDistance(const vector<string>& stops) const{
    double total = 0;
    for (int i = 1; i < stops.size(); ++i){
        const Coordinate start = stops_.at(stops[i - 1]);
        const Coordinate end = stops_.at(stops[i]);
        total += DistanceBetweenCoordinates(start, end);
    }
    return total;
}