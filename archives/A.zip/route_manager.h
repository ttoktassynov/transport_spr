#pragma once
#include <optional>
#include <string>
#include <vector>
#include <unordered_map>
#include <iomanip>

const double PI = 3.1415926535;
const double RADIUS = 6371000;

struct RouteStats{
    size_t stops;
    size_t unique_stops;
    double length;
};

struct Coordinate{
    double lat;
    double lon;
};

double DistanceBetweenCoordinates(const Coordinate& lhs, const Coordinate& rhs);

std::ostream& operator << (std::ostream& output, 
    const std::pair<std::string, std::optional<RouteStats> >stats);

double ConvertToRad(double val);

class RouteManager{
public:
    std::optional<RouteStats> ReadRoute(std::string route) const;
    void AddStop(std::string stop, double lat, double lon);
    void AddRoute(std::string route, std::vector<std::string> stops);
private:
    using RouteInfo = std::vector<std::string>;
    std::unordered_map<std::string, Coordinate> stops_;
    std::unordered_map<std::string, RouteInfo> routes_;

    double ComputeStopsDistance(const std::vector<std::string>& stops) const;
};