#include "test_runner.h"
#include "request.h"
#include "route_manager.h"

int main(){
    //freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);
    RouteManager manager;
    
    const auto update_requests = ReadRequests<0>();
    ProcessRequests(update_requests, manager);
    const auto read_requests = ReadRequests<1>();
    const auto responses = ProcessRequests(read_requests, manager);
    PrintResponses(responses);
}
