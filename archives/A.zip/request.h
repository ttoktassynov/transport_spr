#pragma once
#include "route_manager.h"
#include <string>
#include <string_view>
#include <optional>
#include <deque>
#include <vector>
#include <unordered_map>
#include <iostream>
#include <sstream>

std::pair<std::string_view, std::optional<std::string_view>> SplitTwoStrict(std::string_view s, 
                    std::string_view delimiter = " ");

std::pair<std::string_view, std::string_view> SplitTwo(std::string_view s, 
                    std::string_view delimiter = " ");

std::string_view ReadToken(std::string_view& s, std::string_view delimiter = " ");

int ConvertToInt(std::string_view str);

double ConvertToDouble(std::string_view str);

struct Request;
using RequestHolder = std::unique_ptr<Request>;

struct Request {
  enum class Type {
    ADD_STOP,
    ADD_ROUTE,
    READ_ROUTE
  };

  Request(Type type) : type(type) {}
  static RequestHolder Create(Type type);
  virtual void ParseFrom(std::string_view input) = 0;
  virtual ~Request() = default;

  const Type type;
};

const std::unordered_map<std::string_view, Request::Type> STR_TO_UPDATE_REQUEST_TYPE = {
    {"Stop", Request::Type::ADD_STOP},
    {"Bus", Request::Type::ADD_ROUTE}
};

const std::unordered_map<std::string_view, Request::Type> STR_TO_READ_REQUEST_TYPE = {
    {"Bus", Request::Type::READ_ROUTE}
};

template <typename ResultType>
struct ReadRequest : Request {
  using Request::Request;
  virtual ResultType Process(const RouteManager& manager) const = 0;
};

struct ModifyRequest : Request {
  using Request::Request;
  virtual void Process(RouteManager& manager) const = 0;
};

using ReadRouteData = std::pair<std::string, std::optional<RouteStats> >;

struct ReadRouteRequest : ReadRequest<ReadRouteData> {
  ReadRouteRequest() : ReadRequest(Type::READ_ROUTE) {}
  void ParseFrom(std::string_view input) override;
  ReadRouteData Process(const RouteManager& manager) const override;

  std::string route;
};


struct AddStopRequest : ModifyRequest {
  AddStopRequest() : ModifyRequest(Type::ADD_STOP) {}
  void ParseFrom(std::string_view input) override;
  void Process(RouteManager& manager) const override;

  double lat;
  double lon;
  std::string stop;
};

struct AddRouteRequest : ModifyRequest {
  AddRouteRequest() : ModifyRequest(Type::ADD_ROUTE) {}
  void ParseFrom(std::string_view input) override;
  void Process(RouteManager& manager) const override;
  bool IsCircle(std::string_view input, std::string_view delimeter = " > ");

  std::string route;
  std::vector<std::string> stops;
};

template <typename Number>
Number ReadNumberOnLine(std::istream& stream) {
  Number number;
  stream >> number;
  std::string dummy;
  std::getline(stream, dummy);
  return number;
}

std::optional<Request::Type> ConvertUpdateRequestType(std::string_view type_str);

std::optional<Request::Type> ConvertReadRequestType(std::string_view type_str);

template<int SIGN>
RequestHolder ParseRequest(std::string_view request_str) {
  const auto request_type = SIGN == 0 ? 
        ConvertUpdateRequestType(ReadToken(request_str)) :
        ConvertReadRequestType(ReadToken(request_str));
    
  if (!request_type) {
    return nullptr;
  }
  RequestHolder request = Request::Create(*request_type);
  if (request) {
    request->ParseFrom(request_str);
  };
  return request;
}

template<int SIGN>
std::vector<RequestHolder> ReadRequests(std::istream& in_stream = std::cin) {
  static_assert(SIGN == 0 || SIGN == 1);
  const size_t request_count = ReadNumberOnLine<size_t>(in_stream);

  std::vector<RequestHolder> requests;
  requests.reserve(request_count);

  for (size_t i = 0; i < request_count; ++i) {
    std::string request_str;
    std::getline(in_stream, request_str);
    if (auto request = ParseRequest<SIGN>(request_str)) {
      requests.push_back(move(request));
    }
  }
  return requests;
}

std::vector<ReadRouteData> ProcessRequests(const std::vector<RequestHolder>& requests,
    RouteManager& manager);

void PrintResponses(const std::vector<ReadRouteData>& responses, std::ostream& stream = std::cout);